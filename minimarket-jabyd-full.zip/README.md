# Minimarket JABYD

Repositorio completo con frontend (React + Tailwind) y backend (Node.js + Express + LowDB).

## Instrucciones

1. Instala dependencias en backend y frontend.
2. Ejecuta backend: `cd backend && npm start`
3. Ejecuta frontend: `cd frontend && npm run dev`
