import express from 'express';
import cors from 'cors';
import { Low } from 'lowdb';
import { JSONFile } from 'lowdb/node';
import { join } from 'path';

const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());

// Config DB
const file = join(process.cwd(), 'backend', 'db.json');
const adapter = new JSONFile(file);
const db = new Low(adapter);
await db.read();
db.data ||= { products: [] };

// Routes
app.get('/api/products', (req, res) => {
  res.json(db.data.products);
});

app.post('/api/products', (req, res) => {
  db.data.products.push(req.body);
  db.write();
  res.json({ status: 'ok' });
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});