# Frontend - Minimarket JABYD

Interfaz hecha en **React** para el inventario del minimarket.

## 🚀 Instalación
```bash
cd frontend
npm install
```

## ▶️ Desarrollo
```bash
npm start
```

👉 Corre en `http://localhost:3000` y se conecta con el backend en `http://localhost:4000`.
