import React, { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import ProductList from "./components/ProductList";
import ProductForm from "./components/ProductForm";
import Loader from "./components/Loader";
import "./styles.css";

function App() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const res = await fetch("http://localhost:4000/api/products");
      const data = await res.json();
      setProducts(data);
    } catch (error) {
      console.error("Error cargando productos:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  return (
    <div>
      <Navbar />
      <div className="container">
        <h1>Minimarket JABYD</h1>
        <ProductForm onAdd={fetchProducts} />
        {loading ? <Loader /> : <ProductList products={products} onUpdate={fetchProducts} />}
      </div>
    </div>
  );
}

export default App;
