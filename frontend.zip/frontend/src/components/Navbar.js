import React from "react";

const Navbar = () => (
  <nav className="navbar">
    <div className="logo">🛒 Minimarket JABYD</div>
  </nav>
);

export default Navbar;
