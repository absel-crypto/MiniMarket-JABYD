import React, { useState } from "react";

function ProductForm({ onAdd }) {
  const [form, setForm] = useState({ name: "", price: "", stock: "" });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await fetch("http://localhost:4000/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setForm({ name: "", price: "", stock: "" });
    onAdd();
  };

  return (
    <form className="form" onSubmit={handleSubmit}>
      <input name="name" placeholder="Producto" value={form.name} onChange={handleChange} required />
      <input name="price" type="number" step="0.01" placeholder="Precio" value={form.price} onChange={handleChange} required />
      <input name="stock" type="number" placeholder="Stock" value={form.stock} onChange={handleChange} required />
      <button type="submit">Agregar</button>
    </form>
  );
}

export default ProductForm;
